document.getElementById('submit').addEventListener('click', (event) => {
    event.preventDefault(); // Prevent the form from submitting traditionally

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;

    fetch('http://localhost:3000/api/registration', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: username, email: email, phone: phone, password: password })
    })
    .then(response => {
        if (!response.ok) {
            // If the response is not okay, handle the error
            return response.text().then(errorText => {
                document.getElementById('form').style.display = 'none';
                document.getElementById('alternative').style.display = 'block';
                document.getElementById('alternative').textContent = String(errorText);

                throw new Error(`HTTP error! status: ${response.status}`);
            });
        }
        // If the response is okay, parse the response as JSON
        return response.json();
    })
    .then(data => {
        document.getElementById('form').style.display = 'none';
        document.getElementById('alternative').style.display = 'block';
        document.getElementById('alternative').textContent = "ጥያቄዎን ተቀብለናል፣ በኢሜይል ወይንም በስልክ ምላሽ እስከሚያገኙ ድረስ ይጠብቁ";
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('form').style.display = 'none';
        document.getElementById('alternative').style.display = 'block';
        document.getElementById('alternative').textContent = "ይቅርታ፣ ጥያቄዎን ማስተናገድ አልተቻለም"; // Optional error message for the user
    });
});
